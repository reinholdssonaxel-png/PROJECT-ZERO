# Codex instructions — PROJECT: ZERO

You are the engineering agent for **PROJECT: ZERO**, an original Roblox Studio / Luau hero shooter. Read `PROJECT_SPEC.md` **before implementing or changing game features**; it is the canonical design reference. If a requested change conflicts with it, ask the user or explicitly update the spec after agreement.

## Core mission

Deliver an **actual playable vertical slice**, not isolated snippets or promises. The first slice is first-person **VEX** with **VX-7** and Dash, a grayboxed **HAMNVERKET**, simple bot opponents, HUD, and a functioning repeatable deathmatch loop. Prioritize end-to-end functioning code over speculative content and overengineering.

## Working approach

1. Inspect existing files and repository state first. Never overwrite valuable work blindly.
2. Create a functioning **Rojo** project structure (e.g., `default.project.json`, `src/` server, shared and client modules), `README.md` with exact setup/play instructions and `.gitignore`.
3. Implement the smallest testable increment and describe how it was tested. Continue incrementally: scaffold → VEX camera → VX-7 → server damage → HUD/Dash → bot → map/spawns → game loop → multiplayer test.
4. Prefer authoritative Roblox engine APIs and modern Luau patterns. Build in configurable modules rather than one giant script.
5. Respect **R15** rig design, first-person viewmodels, and Roblox native replication. Keep all important game state and damage server-authoritative. Treat all client input as untrusted and validate rate limits, geometry, ammo, alive state and cooldowns.
6. Write readable code with consistent names and useful comments. Track functionality and known bugs in README or a concise `PROGRESS.md`.
7. Test what can be tested programmatically; if Roblox Studio is not connected, say which parts require hands-on Studio testing. Never pretend to have executed or visually verified Roblox code when tools do not permit it.
8. Use Studio-generated graybox Parts and placeholder meshes/sounds safely. Do not import third-party toolbox models or code without verifying their licensing and auditing scripts. Avoid copying proprietary game models or heroes.
9. Only change the plan when required by gameplay tests or explicit user direction. Update documentation when design changes are accepted.
10. Explain next steps and any blocker clearly in Swedish when communicating with this user; technical code and filenames may be English.

## Fixed initial VEX parameters

- Health **275 HP**; VX-7 **13 damage/body shot**, **9 rounds/sec**, **36 magazine**, **1.8 sec reload**; Dash **8 sec cooldown** (movement reference 18 m/s for 0.18s; tune Roblox studs safely).
- Regen **15 HP/s after 5 seconds without damage**; respawn **8 sec**.
- All unspecified mechanics — including headshot multiplier, Pulse Grenade, Overdrive charge/effect, and other hero tuning — must be explicitly marked **provisional** in configs or remain unimplemented stubs. Do not falsely present guessed values as decisions.

## Deliverables for first pass

- Correct, maintainable Roblox/Rojo source tree.
- Exact instructions to get code into Roblox Studio.
- A testable basic rifle and first-person controller.
- A short implementation checklist: working, incomplete, test-required.

Read `PROJECT_SPEC.md` for the full design, including eight heroes, lore, HAMNVERKET geometry and match flow.
