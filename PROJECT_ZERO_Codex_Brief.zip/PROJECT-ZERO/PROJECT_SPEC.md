# PROJECT: ZERO — Game Design Specification

> Canonical project design reference. Status: pre-alpha planning, October 2026. This is a fictional, original game IP. All values are initial targets subject to playtesting.

## 1. Vision

**PROJECT: ZERO** is a competitive, first-person, class-based hero shooter built in **Roblox Studio (Luau)**. Long-term target: **5v5**, with teams ideally composed of **1 Tank, 2 Damage, 2 Support**. Inspired by the readability and teamwork of hero shooters, but with its own characters, world, silhouettes, lore, branding, maps, and gameplay implementation. Do not copy protected assets or distinctive existing hero designs.

**Visual style:** *Hybrid Future* — grounded Scandinavian industrial environments plus stylized futuristic human armor, helmets and masks. Year **2042**. Palette: slate/steel blue, charcoal, orange and cyan. High gameplay readability and good performance on Roblox clients are priorities. Every playable hero is a normal human using advanced equipment, not a robot or innate superhuman.

**First milestone:** playable first-person test with VEX, VX-7, a simple HAMNVERKET blockout, bots and optional online testing with one friend. Do not attempt eight polished heroes before this slice works.

## 2. Setting & fiction

- **ZERO Initiative:** clandestine research organization developing advanced protective technology. A mysterious incident in Norrhamn caused critical research to disappear.
- **VANGUARD:** international security force.
- **BLACK VEIL:** network of former agents and mercenaries.
- Heroes have differing faction connections and motivations; game teams are not restricted by lore allegiance.
- Time: **2042**. First map situated in a fictional Swedish coastal industrial city called **Norrhamn**.

## 3. First map: HAMNVERKET

- Autumn evening, approximately **20:30**; dark blue sky, damp/wet asphalt, atmospheric reflections, industrial lamps, illuminated containers, brick warehouses, cranes, dockside ship.
- **Never compromise combat visibility for mood:** silhouettes should read, combat spaces clearly lit, optimized effects.
- Initial full-map design target **~160 × 180 meters**; this is a design estimate, **not an instruction to treat 1 stud as exactly 1 meter**. Roblox dimensions need gameplay tuning.
- Three primary routes: **west warehouses**, **central cargo yard**, **east factory/catwalk**.
- One central control point in the principal Control mode.
- **Team Alpha** and **Team Bravo** each have a separate, balanced spawn room with similar pathing/time to point. Futuristic military facilities within old industrial architecture. Large panorama windows looking out to cranes, ship and harbor lights, equipment lockers, digital map/team/timer screens, large automatically opening blast doors. Alpha uses cool blue lighting; Bravo uses warm orange/red lighting. Doors open after match countdown, remain open during play. Spawn protections/anti-camping to be decided and tested.
- Audio: wind, light rain, distant industrial/ship sounds.
- Block out layout and cover before art polish. Avoid unnecessary assets/scripts from Creator Store without auditing licensing, source and embedded scripts.

## 4. Modes and match flow

### Long-term modes

1. **Control:** contest a single objective; a team accrues **1 percentage point per 1.5 seconds** while it controls the point; first to **100%** wins a round; **best of three** rounds.
2. **Escort:** payload/escort objective; rules and balance TBD.
3. **Frontline:** pushing battlefront; rules TBD.

### Hero selection

- Hero selection happens **when a match begins**, not in the main menu. Roughly **30 seconds** to select plus **15 seconds** pre-match preparation. Switching heroes at spawn between lives is intended in later versions.
- First alpha: VEX is the sole playable hero, with other seven visible as unavailable/locked placeholders.
- VEX select animation target (later polish): steps out of shadow, checks VX-7 magazine, orange visor glows, raises rifle and says “Ready for action”; **3–4 seconds**, skippable.

### First playable prototype: Training Deathmatch

- Play as VEX against **1–5 VEX AI bots** using the same basic weapon and stats. Start from one bot and scale to five after performance testing.
- Build toward online **1v1 against a friend on another network** via normal Roblox multiplayer. Eventually fill missing 5v5 spots with AI.
- Target combat pacing: **~2–4 second time-to-kill**, subject to playtesting. Headshot multipliers to be determined. **Health regeneration: 15 HP/sec after 5 seconds with no damage**. Respawn after **8 seconds**. Ensure damage/healing and cooldowns are authoritative on server.

## 5. Heroes (planned roster)

All are armored humans; abilities are technology based. Apart from the VEX gun numbers and HP, the remaining gameplay values are provisional.

| Hero | Role | HP | Visual / weapon / abilities | Backstory |
|---|---|---:|---|---|
| **TITAN** | Tank | **700** | Massive dark-blue heavy armor, narrow blue visor, M-90 heavy cannon; defensive shield and slam | **Viktor Holm**, Sweden, **42**, former military engineer |
| **ATLAS** | Tank | **650** | Industrial orange exosuit, orange visor, mechanical gauntlets; melee attacks and charge | **Marcus Cole**, UK, **36**, exoskeleton engineer |
| **VEX** | Damage | **275** | Black/dark-gray tactical armor, orange visor, **VX-7 assault rifle**; Dash, Pulse Grenade, Overdrive ultimate | **Elias Berg**, Sweden, **29**, former special operative investigating Norrhamn incident |
| **PHANTOM** | Damage | **250** | Black/purple stealth armor and mask, twin pistols; cloak, shadow step, Nightfall ultimate | **Yuna Takahashi**, Japan, **27**, former intelligence operative |
| **HAVOC** | Damage | **300** | Battered red/black heavy explosive armor, grenade launcher; cluster bomb, rocket jump, Annihilator ultimate | **Daniel Reyes**, USA, **34**, explosives specialist |
| **SPECTRE** | Damage | **225** | Hooded sniper mask, green optical lenses, precision rifle; recon dart, grapple, Deadeye ultimate | **Anton Volkov**, Ukraine, **38**, sniper |
| **NOVA** | Support | **250** | White/gray medic armor, cyan visor, energy carbine and healing drone; pulse boost, Revival Field ultimate | **Sofia Lind**, Sweden, **31**, biomedical engineer |
| **ECHO** | Support | **275** | Futuristic protective tech suit, holographic shields, pulse carbine; shield pulse, disruptor, Amplify ultimate | **Adrian Moreau**, France, **33**, technology developer |

### Arsenal direction

**Mixed ballistic/futuristic**. Physical firearms have strong mechanical recoil and sound, augmented with electronics, optics and ammo counters. Exotic weapons have cyan/blue pulse effects but remain grounded in advanced 2042 human tech. Distinct weapon sound, animation and silhouette per hero. For the prototype, use a clean temporary model made in Studio or a vetted licensed asset; no need for final models yet.

### VEX — first implementation (locked initial values)

- Max health: **275**.
- **VX-7:** automatic hitscan/raycast assault rifle, **13 damage per body shot**, **9 shots/sec**, **36 rounds/magazine**, **1.8 second reload**. Headshot multiplier TBD; choose an explicitly documented, configurable prototype value rather than silently assuming canon.
- **Dash:** quick movement burst, reference target **18 m/s for 0.18 sec**, **8 sec cooldown**. Roblox movement units must be calibrated and the dash must be authoritative/validated to prevent speed exploits. Do not hardcode an absurdly short dash distance accidentally due to meters/studs confusion; document conversion and make target distance tuneable.
- **Pulse Grenade:** damage/effect/radius/cooldown TBD — implement as a safe stub until defined.
- **Overdrive Ultimate:** effect/charge/duration TBD — stub until defined.

## 6. Technical architecture

- Engine: **Roblox Studio**. Language: **Luau**. Source files tracked in version control. **Rojo** for filesystem ↔ Studio synchronization where available; provide clear setup instructions and a working `default.project.json` and relevant configuration.
- Avatar rig target: **R15**. First-person camera with local weapon/arms viewmodel; third-person character/weapon representation for others. Use Roblox Animator / Animation Editor, with placeholder animation if necessary.
- Client owns immediate local feel: camera bob/recoil, crosshair, sound and VFX. **Server owns health, ammo/cooldowns, actual firing eligibility, damage, bot state, kills and respawns.** Validate RemoteEvents: firing rate, origin/direction plausibility, range, wall collision, alive state, team/friendly fire, ammo and reload status.
- Hitscan gun via raycasts; future launcher projectiles separately. Be conservative about trusting client-reported hits; design for latency without making hit registration trivially exploitable.
- Bots: server-controlled AI using Roblox `PathfindingService` when practical, line-of-sight checks, aiming/firing, cooldowns, respawn. Start simple and performant before advanced behaviors.
- UI: health, ammo/reload, ability cooldown, reticle and match/bot state. Full hero selection later.
- Visuals: `Lighting`, `Atmosphere`, `ColorCorrectionEffect`, restrained lights/particles; avoid unnecessarily expensive real-time effects.
- Test single-player first, then Roblox Studio local multi-client tests, then published/private-session online tests with a consenting friend; multiplayer does not require independently hosted servers.
- Roblox Creator Store assets are optional; never treat free assets as automatically safe. Inspect scripts, provenance, rights and compatibility. A kit like Roblox's official Weapons Kit can be used as a **reference or throwaway test**, but do not couple the core game to an unaudited third-party framework. First-person requirement and R15 compatibility are non-negotiable design goals.

## 7. Development priority

1. Project scaffold + Rojo sync + readme + playable Roblox place.
2. R15 VEX movement, camera, health and basic spawns.
3. **VX-7 shooting**, ammunition, reload, recoil, FX, server-validated hit/damage.
4. Dash ability, HUD.
5. One AI VEX bot that moves/shoots/respawns; scale to several.
6. HAMNVERKET graybox with 3 lanes, cover and Alpha/Bravo spawn rooms and their harbor-view windows. Keep combat sightlines fair.
7. First loop: Training Deathmatch, respawn, score, basic win/reset.
8. Test one friend on separate networks; fix networking and exploit issues.
9. Polish visuals/audio; add Control mode; later remaining heroes, modes and matchmaking.

**Aspirational one-week sprint** for 20–26 October 2026 (5–8 h/day available): movement/scaffold → VX-7/Dash → bot → map → HUD/game loop → friend test → polish. **This is a target, not a promise**. Cut features if needed to preserve a functioning prototype.

## 8. Minimum playable acceptance criteria

- A developer can follow README, synchronize/install the source, press Play in Roblox Studio and control VEX in first-person.
- VX-7 shoots visible effects, fires max 9/sec, consumes magazine, reloads in ~1.8 sec and applies 13 damage per validated body hit on server.
- Damage, deaths, respawn (8sec), health regeneration and ammo behave reliably and cannot simply be overridden via obvious RemoteEvent spam.
- Dash works and respects cooldown.
- At least one VEX AI bot navigates a basic test environment, detects the player, can attack, be eliminated and respawn.
- A basic industrial map, two distinct spawn areas, and working HUD exist. It is acceptable to use placeholders before final art.
- Any features not working or awaiting specification are clearly called out in README instead of claimed complete.

## 9. Product decisions and design discipline

- Prioritize **real playable mechanics** over presentation-only demos.
- Do not replace agreed character names/stats or invent unrelated heroes (e.g., no BASTION).
- Keep all balancing constants in configuration, with code separated by responsibilities.
- Communicate implementation status accurately and avoid asserting something works unless tested.
- Avoid using third-party IP, unlicensed models, undisclosed external dependencies or suspicious toolbox scripts.
- UI and developer instructions can be in Swedish or English; player-facing terms can evolve. Character names and world terms above are canon.
